<!DOCTYPE html>
<!--
'+++++`        .+++++++++++++++       ,::::,        ++++++     .++++,      
'+++++`       .+++++++++++++++     .::::::::::,     ++++++  '+++++++++'   
 +++++;       ++++++++++++++++    ::::::::::::::    ++++++ +++++++++++++  
 ++++++       ++++++++++++++++   ::::::::::::::::   ++++++'+++++++++++++' 
 '+++++       ++++++++++++++++  ,::::::::::::::::,  ++++++++++++.`;++++++ 
 `+++++.     ,++++++++          :::::::    :::::::  +++++++++++     +++++ 
  +++++'     +++++++++          ::::::      ::::::  ++++++++++      +++++ 
  '+++++     +++++++++         `:::::,      .:::::. ++++++++++:           
  `+++++     +++++++++         `:::::        :::::, +++++++++++:          
   +++++:   '+++++++++         `:::::        :::::, +++++++++++++;        
   ++++++   ++++++++++++++++++ `:::::        :::::, ++++++++++++++++`     
   `+++++   ++2018 venis s&s++ `:::::        :::::, ++++++ ++++++++++:   
    +++++`  ++++++++++++++++++ `:::::        :::::, ++++++  ++++++++++++  
    +++++; '++++ +++++++++++++ `:::::        :::::, ++++++    ;++++++++++ 
    .+++++ +++++ +++++         `:::::        :::::, ++++++      .++++++++ 
     +++++ ++++' +++++         `:::::        :::::, ++++++         +++++++
     +++++,++++` +++++         `:::::        :::::, ++++++          ++++++
     ,+++++++++  +++++         `:::::        :::::, ++++++;;;;      ,+++++
      +++++++++  +++++         `:::::        :::::, ++++++++++      ++++++
      ++++++++`  +++++........ `:::::        :::::, +++++++++++,   ;+++++,
      :+++++++   +++++++++++++ `:::::        :::::, +++++++++++++++++++++ 
       +++++++   +++++++++++++ `:::::        :::::, ++++++++++++++++++++` 
       ++++++,   +++++++++++++ `:::::        :::::, ++++++ ++++++++++++`  
       ;+++++    +++++++++++++ `:::::        :::::, ++++++  .++++++++;    
--><!--[if IE 8]><html class="no-js ie89 ie8" lang="it"><![endif]-->
<!--[if IE 9]><html class="no-js ie89 ie9" lang="it"><![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html class="no-js" lang="it" dir="ltr" prefix="og: http://opengraphprotocol.org/schema/">
    <!--<![endif]-->

    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="Comune di Venezia - Venis SpA" />
        <meta name="description" content="Risultati ufficiali delle Elezioni Politiche 2018 nel Comune di Venezia" />
        <meta name="apple-mobile-web-app-capable" content="yes">
<!--        <meta http-equiv="refresh" content="140">-->
        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Expires" content="0" />
        <link rel="image_src" type="image/png" href="http://elezioni.comune.venezia.it/citta-venezia.png" />       
        <meta property="og:title" content="Comune di Venezia - Elezioni Politiche 2018">
        <meta property="og:description" content="Sito ufficiale delle Elezioni Politiche del 4 marzo 2018 nel Comune di Venezia. Risultati in tempo reale dello spoglio per l'elezione del Senato della Repubblica e della Camera dei Deputati">
        <meta property="og:url" content="http://elezioni.comune.venezia.it/">
        <script type="text/javascript">
            WebFontConfig = {
                google: {
                    families: ['Titillium+Web:300,400,600,700,400italic:latin']
                }
            };
            (function () {
                var wf = document.createElement('script');
                wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
                wf.type = 'text/javascript';
                wf.async = 'true';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(wf, s);
            })();
        </script>

        <!-- include HTML5shim per Explorer 8 -->
        <script src="/build/vendor/modernizr.js"></script>
        <link media="all" rel="stylesheet" href="/build/build.css">
        <script src="/build/vendor/jquery.min.js"></script>
                <title>Elezioni Politiche 4 marzo 2018 - Comune di Venezia</title>
        <link rel="shortcut icon" href="/favicon.ico" type="image/vnd.microsoft.icon" />
        <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="76x76" href="/apple-touch-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">
    </head>

    <body class="t-Pac">
        <ul class="Skiplinks js-fr-bypasslinks u-hiddenPrint">
            <li><a href="#main">Vai al Contenuto</a></li>
            <li><a class="js-fr-offcanvas-open" href="#menu"
                   aria-controls="menu" aria-label="accedi al menu" title="accedi al menu">Vai alla navigazione del sito</a></li>
        </ul>


        <header class="Header  u-hiddenPrint">
                        <div class="Header-navbar ">
                <div class="u-layout-wide Grid Grid--alignMiddle u-layoutCenter">
                    <div class="Header-logo Grid-cell" aria-hidden="true">
                        <a href="/" tabindex="-1">
                            <img src="/immagini/logo/come-di-venezia_logo.png" alt="">
                        </a>
                    </div>

                    <div class="Header-title Grid-cell">
                        <h1 class="Header-titleLink">
                            <a href="/">
                                Elezioni Politiche 4 marzo 2018
                            </a>
                        </h1>
                    </div>



                    <div class="Header-utils Grid-cell">
                        <div class="Header-social Headroom-hideme">
                            <p>Seguici su</p>
                            <ul class="Header-socialIcons">
                                <li><a href="https://it-it.facebook.com/ComunediVenezia/" title="Facebook"><span class="Icon-facebook"></span><span class="u-hiddenVisually">Facebook</span></a></li>
                                <li><a href="https://www.instagram.com/comunevenezia/" title="Instagram"><span class="Icon-instagram"></span><span class="u-hiddenVisually">Instagram</span></a></li>
                                <li><a href="https://twitter.com/comunevenezia" title="Twitter"><span class="Icon-twitter"></span><span class="u-hiddenVisually">Twitter</span></a></li>
                                <li><a href="https://www.youtube.com/channel/UCHQPCBBahWU0G1SvQgjomHw" title="Youtube"><span class="Icon-youtube"></span><span class="u-hiddenVisually">Youtube</span></a></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div id="menu-nav" class="Header-toggle Grid-cell">
                    <a class="Hamburger-toggleContainer js-fr-offcanvas-open u-nojsDisplayInlineBlock u-lg-hidden u-md-hidden" href="#menu"
                       aria-controls="menu" aria-label="accedi al menu" title="accedi al menu">
                        <span class="Hamburger-toggle" role="presentation"></span>
                        <span class="Header-toggleText" role="presentation">Menu</span>
                    </a>
                </div>

            </div>
        </div>
        <!-- Header-navbar -->
        

        <div class="Headroom-hideme u-textCenter u-hidden u-sm-hidden u-md-block u-lg-block">

            <nav class="Megamenu Megamenu--default js-megamenu " data-rel=".Offcanvas .Treeview"></nav>

        </div>


    </header>


    
    <section class="Offcanvas Offcanvas--right Offcanvas--modal js-fr-offcanvas u-jsVisibilityHidden u-nojsDisplayNone u-hiddenPrint" id="menu">
    <h2 class="u-hiddenVisually">Menu di navigazione</h2>
    <div class="Offcanvas-content u-background-white">
        <div class="Offcanvas-toggleContainer u-background-70 u-jsHidden">
            <a class="Hamburger-toggleContainer u-block u-color-white u-padding-bottom-xxl u-padding-left-s u-padding-top-xxl js-fr-offcanvas-close"
               aria-controls="menu" aria-label="esci dalla navigazione" title="esci dalla navigazione" href="#">
                <span class="Hamburger-toggle is-active" aria-hidden="true"></span>
            </a>
        </div>
        <nav>
            <ul class="Linklist Linklist--padded Treeview Treeview--default js-Treeview u-text-r-xs">
                <li><a href="#">Senato della Repubblica</a>
                    <ul>
                        <li><a href="/risultati/451/A/30241">Intero comune</a>
                            <ul>	
                                <li><div><a href="/risultati/451/A/30241">Risultati</a></div></li>
                                <li><div><a href="/affluenze.php">Affluenze</a></div></li>
                            </ul>
                        </li>

                        <li><a href="/risultati/451/A/20201">Zone e Municipalità</a>
                            <ul>
                                <li><div><a href="/risultati/451/A/20201">Centro Storico</a></div></li>
                                <li><div><a href="/risultati/451/A/20202">Estuario</a></div></li>
                                <li><div><a href="/risultati/451/A/20203">Terraferma</a></div></li>
                                <li><div> --- </div></li>
                                <li><div><a href="/risultati/451/A/30243">Venezia-Murano-Burano</a></div></li>
                                <li><div><a href="/risultati/451/A/30245">Lido-Pellestrina</a></div></li>
                                <li><div><a href="/risultati/451/A/30247">Favaro Veneto</a></div></li>
                                <li><div><a href="/risultati/451/A/30249">Mestre-Carpenedo</a></div></li>
                                <li><div><a href="/risultati/451/A/30251">Chirignago-Zelarino</a></div></li>
                                <li><div><a href="/risultati/451/A/30253">Marghera</a></div></li>
                            </ul>
                        </li>
                        <li><a href="/risultati/451/S/1">Sezioni</a>
                            <ul>
                                <li><div><select onchange="location.href = '/risultati/451/S/' + this.options[this.selectedIndex].value + ''">
                                            <option value="">Seleziona una sezione</option>
                                                                                            <option value="1">Sezione 1</option>
                                                                                                <option value="2">Sezione 2</option>
                                                                                                <option value="3">Sezione 3</option>
                                                                                                <option value="4">Sezione 4</option>
                                                                                                <option value="5">Sezione 5</option>
                                                                                                <option value="6">Sezione 6</option>
                                                                                                <option value="7">Sezione 7</option>
                                                                                                <option value="8">Sezione 8</option>
                                                                                                <option value="9">Sezione 9</option>
                                                                                                <option value="10">Sezione 10</option>
                                                                                                <option value="11">Sezione 11</option>
                                                                                                <option value="12">Sezione 12</option>
                                                                                                <option value="13">Sezione 13</option>
                                                                                                <option value="14">Sezione 14</option>
                                                                                                <option value="15">Sezione 15</option>
                                                                                                <option value="16">Sezione 16</option>
                                                                                                <option value="17">Sezione 17</option>
                                                                                                <option value="18">Sezione 18</option>
                                                                                                <option value="19">Sezione 19</option>
                                                                                                <option value="20">Sezione 20</option>
                                                                                                <option value="21">Sezione 21</option>
                                                                                                <option value="22">Sezione 22</option>
                                                                                                <option value="23">Sezione 23</option>
                                                                                                <option value="24">Sezione 24</option>
                                                                                                <option value="25">Sezione 25</option>
                                                                                                <option value="26">Sezione 26</option>
                                                                                                <option value="27">Sezione 27</option>
                                                                                                <option value="28">Sezione 28</option>
                                                                                                <option value="29">Sezione 29</option>
                                                                                                <option value="30">Sezione 30</option>
                                                                                                <option value="31">Sezione 31</option>
                                                                                                <option value="32">Sezione 32</option>
                                                                                                <option value="33">Sezione 33</option>
                                                                                                <option value="34">Sezione 34</option>
                                                                                                <option value="35">Sezione 35</option>
                                                                                                <option value="36">Sezione 36</option>
                                                                                                <option value="37">Sezione 37</option>
                                                                                                <option value="38">Sezione 38</option>
                                                                                                <option value="39">Sezione 39</option>
                                                                                                <option value="40">Sezione 40</option>
                                                                                                <option value="41">Sezione 41</option>
                                                                                                <option value="42">Sezione 42</option>
                                                                                                <option value="43">Sezione 43</option>
                                                                                                <option value="44">Sezione 44</option>
                                                                                                <option value="45">Sezione 45</option>
                                                                                                <option value="46">Sezione 46</option>
                                                                                                <option value="47">Sezione 47</option>
                                                                                                <option value="48">Sezione 48</option>
                                                                                                <option value="49">Sezione 49</option>
                                                                                                <option value="50">Sezione 50</option>
                                                                                                <option value="51">Sezione 51</option>
                                                                                                <option value="52">Sezione 52</option>
                                                                                                <option value="53">Sezione 53</option>
                                                                                                <option value="54">Sezione 54</option>
                                                                                                <option value="55">Sezione 55</option>
                                                                                                <option value="56">Sezione 56</option>
                                                                                                <option value="57">Sezione 57</option>
                                                                                                <option value="58">Sezione 58</option>
                                                                                                <option value="59">Sezione 59</option>
                                                                                                <option value="60">Sezione 60</option>
                                                                                                <option value="61">Sezione 61</option>
                                                                                                <option value="62">Sezione 62</option>
                                                                                                <option value="63">Sezione 63</option>
                                                                                                <option value="64">Sezione 64</option>
                                                                                                <option value="65">Sezione 65</option>
                                                                                                <option value="66">Sezione 66</option>
                                                                                                <option value="67">Sezione 67</option>
                                                                                                <option value="68">Sezione 68</option>
                                                                                                <option value="69">Sezione 69</option>
                                                                                                <option value="70">Sezione 70</option>
                                                                                                <option value="71">Sezione 71</option>
                                                                                                <option value="72">Sezione 72</option>
                                                                                                <option value="73">Sezione 73</option>
                                                                                                <option value="74">Sezione 74</option>
                                                                                                <option value="75">Sezione 75</option>
                                                                                                <option value="76">Sezione 76</option>
                                                                                                <option value="77">Sezione 77</option>
                                                                                                <option value="78">Sezione 78</option>
                                                                                                <option value="79">Sezione 79</option>
                                                                                                <option value="80">Sezione 80</option>
                                                                                                <option value="81">Sezione 81</option>
                                                                                                <option value="82">Sezione 82</option>
                                                                                                <option value="83">Sezione 83</option>
                                                                                                <option value="84">Sezione 84</option>
                                                                                                <option value="85">Sezione 85</option>
                                                                                                <option value="86">Sezione 86</option>
                                                                                                <option value="87">Sezione 87</option>
                                                                                                <option value="88">Sezione 88</option>
                                                                                                <option value="89">Sezione 89</option>
                                                                                                <option value="90">Sezione 90</option>
                                                                                                <option value="91">Sezione 91</option>
                                                                                                <option value="92">Sezione 92</option>
                                                                                                <option value="93">Sezione 93</option>
                                                                                                <option value="94">Sezione 94</option>
                                                                                                <option value="95">Sezione 95</option>
                                                                                                <option value="96">Sezione 96</option>
                                                                                                <option value="97">Sezione 97</option>
                                                                                                <option value="98">Sezione 98</option>
                                                                                                <option value="99">Sezione 99</option>
                                                                                                <option value="100">Sezione 100</option>
                                                                                                <option value="101">Sezione 101</option>
                                                                                                <option value="102">Sezione 102</option>
                                                                                                <option value="103">Sezione 103</option>
                                                                                                <option value="104">Sezione 104</option>
                                                                                                <option value="105">Sezione 105</option>
                                                                                                <option value="106">Sezione 106</option>
                                                                                                <option value="107">Sezione 107</option>
                                                                                                <option value="108">Sezione 108</option>
                                                                                                <option value="109">Sezione 109</option>
                                                                                                <option value="110">Sezione 110</option>
                                                                                                <option value="111">Sezione 111</option>
                                                                                                <option value="112">Sezione 112</option>
                                                                                                <option value="113">Sezione 113</option>
                                                                                                <option value="114">Sezione 114</option>
                                                                                                <option value="115">Sezione 115</option>
                                                                                                <option value="116">Sezione 116</option>
                                                                                                <option value="117">Sezione 117</option>
                                                                                                <option value="118">Sezione 118</option>
                                                                                                <option value="119">Sezione 119</option>
                                                                                                <option value="120">Sezione 120</option>
                                                                                                <option value="121">Sezione 121</option>
                                                                                                <option value="122">Sezione 122</option>
                                                                                                <option value="123">Sezione 123</option>
                                                                                                <option value="124">Sezione 124</option>
                                                                                                <option value="125">Sezione 125</option>
                                                                                                <option value="126">Sezione 126</option>
                                                                                                <option value="127">Sezione 127</option>
                                                                                                <option value="128">Sezione 128</option>
                                                                                                <option value="129">Sezione 129</option>
                                                                                                <option value="130">Sezione 130</option>
                                                                                                <option value="131">Sezione 131</option>
                                                                                                <option value="132">Sezione 132</option>
                                                                                                <option value="133">Sezione 133</option>
                                                                                                <option value="134">Sezione 134</option>
                                                                                                <option value="135">Sezione 135</option>
                                                                                                <option value="136">Sezione 136</option>
                                                                                                <option value="137">Sezione 137</option>
                                                                                                <option value="138">Sezione 138</option>
                                                                                                <option value="139">Sezione 139</option>
                                                                                                <option value="140">Sezione 140</option>
                                                                                                <option value="141">Sezione 141</option>
                                                                                                <option value="142">Sezione 142</option>
                                                                                                <option value="143">Sezione 143</option>
                                                                                                <option value="144">Sezione 144</option>
                                                                                                <option value="145">Sezione 145</option>
                                                                                                <option value="146">Sezione 146</option>
                                                                                                <option value="147">Sezione 147</option>
                                                                                                <option value="148">Sezione 148</option>
                                                                                                <option value="149">Sezione 149</option>
                                                                                                <option value="150">Sezione 150</option>
                                                                                                <option value="151">Sezione 151</option>
                                                                                                <option value="152">Sezione 152</option>
                                                                                                <option value="153">Sezione 153</option>
                                                                                                <option value="154">Sezione 154</option>
                                                                                                <option value="155">Sezione 155</option>
                                                                                                <option value="156">Sezione 156</option>
                                                                                                <option value="157">Sezione 157</option>
                                                                                                <option value="158">Sezione 158</option>
                                                                                                <option value="159">Sezione 159</option>
                                                                                                <option value="160">Sezione 160</option>
                                                                                                <option value="161">Sezione 161</option>
                                                                                                <option value="162">Sezione 162</option>
                                                                                                <option value="163">Sezione 163</option>
                                                                                                <option value="164">Sezione 164</option>
                                                                                                <option value="165">Sezione 165</option>
                                                                                                <option value="166">Sezione 166</option>
                                                                                                <option value="167">Sezione 167</option>
                                                                                                <option value="168">Sezione 168</option>
                                                                                                <option value="169">Sezione 169</option>
                                                                                                <option value="170">Sezione 170</option>
                                                                                                <option value="171">Sezione 171</option>
                                                                                                <option value="172">Sezione 172</option>
                                                                                                <option value="173">Sezione 173</option>
                                                                                                <option value="174">Sezione 174</option>
                                                                                                <option value="175">Sezione 175</option>
                                                                                                <option value="176">Sezione 176</option>
                                                                                                <option value="177">Sezione 177</option>
                                                                                                <option value="178">Sezione 178</option>
                                                                                                <option value="179">Sezione 179</option>
                                                                                                <option value="180">Sezione 180</option>
                                                                                                <option value="181">Sezione 181</option>
                                                                                                <option value="182">Sezione 182</option>
                                                                                                <option value="183">Sezione 183</option>
                                                                                                <option value="184">Sezione 184</option>
                                                                                                <option value="185">Sezione 185</option>
                                                                                                <option value="186">Sezione 186</option>
                                                                                                <option value="187">Sezione 187</option>
                                                                                                <option value="188">Sezione 188</option>
                                                                                                <option value="189">Sezione 189</option>
                                                                                                <option value="190">Sezione 190</option>
                                                                                                <option value="191">Sezione 191</option>
                                                                                                <option value="192">Sezione 192</option>
                                                                                                <option value="193">Sezione 193</option>
                                                                                                <option value="194">Sezione 194</option>
                                                                                                <option value="195">Sezione 195</option>
                                                                                                <option value="196">Sezione 196</option>
                                                                                                <option value="197">Sezione 197</option>
                                                                                                <option value="198">Sezione 198</option>
                                                                                                <option value="199">Sezione 199</option>
                                                                                                <option value="200">Sezione 200</option>
                                                                                                <option value="201">Sezione 201</option>
                                                                                                <option value="202">Sezione 202</option>
                                                                                                <option value="203">Sezione 203</option>
                                                                                                <option value="204">Sezione 204</option>
                                                                                                <option value="205">Sezione 205</option>
                                                                                                <option value="206">Sezione 206</option>
                                                                                                <option value="207">Sezione 207</option>
                                                                                                <option value="208">Sezione 208</option>
                                                                                                <option value="209">Sezione 209</option>
                                                                                                <option value="210">Sezione 210</option>
                                                                                                <option value="211">Sezione 211</option>
                                                                                                <option value="212">Sezione 212</option>
                                                                                                <option value="213">Sezione 213</option>
                                                                                                <option value="214">Sezione 214</option>
                                                                                                <option value="215">Sezione 215</option>
                                                                                                <option value="216">Sezione 216</option>
                                                                                                <option value="217">Sezione 217</option>
                                                                                                <option value="218">Sezione 218</option>
                                                                                                <option value="219">Sezione 219</option>
                                                                                                <option value="220">Sezione 220</option>
                                                                                                <option value="221">Sezione 221</option>
                                                                                                <option value="222">Sezione 222</option>
                                                                                                <option value="223">Sezione 223</option>
                                                                                                <option value="224">Sezione 224</option>
                                                                                                <option value="225">Sezione 225</option>
                                                                                                <option value="226">Sezione 226</option>
                                                                                                <option value="227">Sezione 227</option>
                                                                                                <option value="228">Sezione 228</option>
                                                                                                <option value="229">Sezione 229</option>
                                                                                                <option value="230">Sezione 230</option>
                                                                                                <option value="231">Sezione 231</option>
                                                                                                <option value="232">Sezione 232</option>
                                                                                                <option value="233">Sezione 233</option>
                                                                                                <option value="234">Sezione 234</option>
                                                                                                <option value="235">Sezione 235</option>
                                                                                                <option value="236">Sezione 236</option>
                                                                                                <option value="237">Sezione 237</option>
                                                                                                <option value="238">Sezione 238</option>
                                                                                                <option value="239">Sezione 239</option>
                                                                                                <option value="240">Sezione 240</option>
                                                                                                <option value="241">Sezione 241</option>
                                                                                                <option value="242">Sezione 242</option>
                                                                                                <option value="243">Sezione 243</option>
                                                                                                <option value="244">Sezione 244</option>
                                                                                                <option value="245">Sezione 245</option>
                                                                                                <option value="246">Sezione 246</option>
                                                                                                <option value="247">Sezione 247</option>
                                                                                                <option value="248">Sezione 248</option>
                                                                                                <option value="249">Sezione 249</option>
                                                                                                <option value="250">Sezione 250</option>
                                                                                                <option value="251">Sezione 251</option>
                                                                                                <option value="252">Sezione 252</option>
                                                                                                <option value="253">Sezione 253</option>
                                                                                                <option value="254">Sezione 254</option>
                                                                                                <option value="255">Sezione 255</option>
                                                                                                <option value="256">Sezione 256</option>
                                                                                        </select> </div></li>

                            </ul>
                        </li>
                        <li><a href="/mappa-voto-risultati-senato.php#menu-nav">Mappe del voto</a>
                            <ul>
                                <li><div><a href="/mappa-voto-risultati-senato.php#menu-nav">Mappa del voto</a></div></li>

                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#">Camera dei Deputati</a>
                    <ul>
                        <li><a href="/risultati/447/A/30241">Intero comune</a>
                            <ul>
                                <li><div><a href="/risultati/447/A/30241">Risultati</a></div></li>
                                <li><div><a href="/affluenze.php">Affluenze</a></div></li>
                            </ul>
                        </li>
                        <li><a href="/risultati/447/A/20201">Zone e Municipalità</a>
                            <ul>
                                <li><div><a href="/risultati/447/A/20201">Centro Storico</a></div></li>
                                <li><div><a href="/risultati/447/A/20202">Estuario</a></div></li>
                                <li><div><a href="/risultati/447/A/20203">Terraferma</a></div></li>

                                <li><div> --- </div></li>
                                <li><div><a href="/risultati/447/A/30243">Venezia-Murano-Burano</a></div></li>
                                <li><div><a href="/risultati/447/A/30245">Lido-Pellestrina</a></div></li>
                                <li><div><a href="/risultati/447/A/30247">Favaro Veneto</a></div></li>
                                <li><div><a href="/risultati/447/A/30249">Mestre-Carpenedo</a></div></li>
                                <li><div><a href="/risultati/447/A/30251">Chirignago-Zelarino</a></div></li>
                                <li><div><a href="/risultati/447/A/30253">Marghera</a></div></li>
                            </ul>
                        </li>
                        <li><a href="risultati/447/S/1">Sezioni</a>
                            <ul>
                                <li><div><select onchange="location.href = '/risultati/447/S/' + this.options[this.selectedIndex].value + ''">
                                            <option value="">Seleziona una sezione</option>
                                                                                            <option value="1">Sezione 1</option>
                                                                                                <option value="2">Sezione 2</option>
                                                                                                <option value="3">Sezione 3</option>
                                                                                                <option value="4">Sezione 4</option>
                                                                                                <option value="5">Sezione 5</option>
                                                                                                <option value="6">Sezione 6</option>
                                                                                                <option value="7">Sezione 7</option>
                                                                                                <option value="8">Sezione 8</option>
                                                                                                <option value="9">Sezione 9</option>
                                                                                                <option value="10">Sezione 10</option>
                                                                                                <option value="11">Sezione 11</option>
                                                                                                <option value="12">Sezione 12</option>
                                                                                                <option value="13">Sezione 13</option>
                                                                                                <option value="14">Sezione 14</option>
                                                                                                <option value="15">Sezione 15</option>
                                                                                                <option value="16">Sezione 16</option>
                                                                                                <option value="17">Sezione 17</option>
                                                                                                <option value="18">Sezione 18</option>
                                                                                                <option value="19">Sezione 19</option>
                                                                                                <option value="20">Sezione 20</option>
                                                                                                <option value="21">Sezione 21</option>
                                                                                                <option value="22">Sezione 22</option>
                                                                                                <option value="23">Sezione 23</option>
                                                                                                <option value="24">Sezione 24</option>
                                                                                                <option value="25">Sezione 25</option>
                                                                                                <option value="26">Sezione 26</option>
                                                                                                <option value="27">Sezione 27</option>
                                                                                                <option value="28">Sezione 28</option>
                                                                                                <option value="29">Sezione 29</option>
                                                                                                <option value="30">Sezione 30</option>
                                                                                                <option value="31">Sezione 31</option>
                                                                                                <option value="32">Sezione 32</option>
                                                                                                <option value="33">Sezione 33</option>
                                                                                                <option value="34">Sezione 34</option>
                                                                                                <option value="35">Sezione 35</option>
                                                                                                <option value="36">Sezione 36</option>
                                                                                                <option value="37">Sezione 37</option>
                                                                                                <option value="38">Sezione 38</option>
                                                                                                <option value="39">Sezione 39</option>
                                                                                                <option value="40">Sezione 40</option>
                                                                                                <option value="41">Sezione 41</option>
                                                                                                <option value="42">Sezione 42</option>
                                                                                                <option value="43">Sezione 43</option>
                                                                                                <option value="44">Sezione 44</option>
                                                                                                <option value="45">Sezione 45</option>
                                                                                                <option value="46">Sezione 46</option>
                                                                                                <option value="47">Sezione 47</option>
                                                                                                <option value="48">Sezione 48</option>
                                                                                                <option value="49">Sezione 49</option>
                                                                                                <option value="50">Sezione 50</option>
                                                                                                <option value="51">Sezione 51</option>
                                                                                                <option value="52">Sezione 52</option>
                                                                                                <option value="53">Sezione 53</option>
                                                                                                <option value="54">Sezione 54</option>
                                                                                                <option value="55">Sezione 55</option>
                                                                                                <option value="56">Sezione 56</option>
                                                                                                <option value="57">Sezione 57</option>
                                                                                                <option value="58">Sezione 58</option>
                                                                                                <option value="59">Sezione 59</option>
                                                                                                <option value="60">Sezione 60</option>
                                                                                                <option value="61">Sezione 61</option>
                                                                                                <option value="62">Sezione 62</option>
                                                                                                <option value="63">Sezione 63</option>
                                                                                                <option value="64">Sezione 64</option>
                                                                                                <option value="65">Sezione 65</option>
                                                                                                <option value="66">Sezione 66</option>
                                                                                                <option value="67">Sezione 67</option>
                                                                                                <option value="68">Sezione 68</option>
                                                                                                <option value="69">Sezione 69</option>
                                                                                                <option value="70">Sezione 70</option>
                                                                                                <option value="71">Sezione 71</option>
                                                                                                <option value="72">Sezione 72</option>
                                                                                                <option value="73">Sezione 73</option>
                                                                                                <option value="74">Sezione 74</option>
                                                                                                <option value="75">Sezione 75</option>
                                                                                                <option value="76">Sezione 76</option>
                                                                                                <option value="77">Sezione 77</option>
                                                                                                <option value="78">Sezione 78</option>
                                                                                                <option value="79">Sezione 79</option>
                                                                                                <option value="80">Sezione 80</option>
                                                                                                <option value="81">Sezione 81</option>
                                                                                                <option value="82">Sezione 82</option>
                                                                                                <option value="83">Sezione 83</option>
                                                                                                <option value="84">Sezione 84</option>
                                                                                                <option value="85">Sezione 85</option>
                                                                                                <option value="86">Sezione 86</option>
                                                                                                <option value="87">Sezione 87</option>
                                                                                                <option value="88">Sezione 88</option>
                                                                                                <option value="89">Sezione 89</option>
                                                                                                <option value="90">Sezione 90</option>
                                                                                                <option value="91">Sezione 91</option>
                                                                                                <option value="92">Sezione 92</option>
                                                                                                <option value="93">Sezione 93</option>
                                                                                                <option value="94">Sezione 94</option>
                                                                                                <option value="95">Sezione 95</option>
                                                                                                <option value="96">Sezione 96</option>
                                                                                                <option value="97">Sezione 97</option>
                                                                                                <option value="98">Sezione 98</option>
                                                                                                <option value="99">Sezione 99</option>
                                                                                                <option value="100">Sezione 100</option>
                                                                                                <option value="101">Sezione 101</option>
                                                                                                <option value="102">Sezione 102</option>
                                                                                                <option value="103">Sezione 103</option>
                                                                                                <option value="104">Sezione 104</option>
                                                                                                <option value="105">Sezione 105</option>
                                                                                                <option value="106">Sezione 106</option>
                                                                                                <option value="107">Sezione 107</option>
                                                                                                <option value="108">Sezione 108</option>
                                                                                                <option value="109">Sezione 109</option>
                                                                                                <option value="110">Sezione 110</option>
                                                                                                <option value="111">Sezione 111</option>
                                                                                                <option value="112">Sezione 112</option>
                                                                                                <option value="113">Sezione 113</option>
                                                                                                <option value="114">Sezione 114</option>
                                                                                                <option value="115">Sezione 115</option>
                                                                                                <option value="116">Sezione 116</option>
                                                                                                <option value="117">Sezione 117</option>
                                                                                                <option value="118">Sezione 118</option>
                                                                                                <option value="119">Sezione 119</option>
                                                                                                <option value="120">Sezione 120</option>
                                                                                                <option value="121">Sezione 121</option>
                                                                                                <option value="122">Sezione 122</option>
                                                                                                <option value="123">Sezione 123</option>
                                                                                                <option value="124">Sezione 124</option>
                                                                                                <option value="125">Sezione 125</option>
                                                                                                <option value="126">Sezione 126</option>
                                                                                                <option value="127">Sezione 127</option>
                                                                                                <option value="128">Sezione 128</option>
                                                                                                <option value="129">Sezione 129</option>
                                                                                                <option value="130">Sezione 130</option>
                                                                                                <option value="131">Sezione 131</option>
                                                                                                <option value="132">Sezione 132</option>
                                                                                                <option value="133">Sezione 133</option>
                                                                                                <option value="134">Sezione 134</option>
                                                                                                <option value="135">Sezione 135</option>
                                                                                                <option value="136">Sezione 136</option>
                                                                                                <option value="137">Sezione 137</option>
                                                                                                <option value="138">Sezione 138</option>
                                                                                                <option value="139">Sezione 139</option>
                                                                                                <option value="140">Sezione 140</option>
                                                                                                <option value="141">Sezione 141</option>
                                                                                                <option value="142">Sezione 142</option>
                                                                                                <option value="143">Sezione 143</option>
                                                                                                <option value="144">Sezione 144</option>
                                                                                                <option value="145">Sezione 145</option>
                                                                                                <option value="146">Sezione 146</option>
                                                                                                <option value="147">Sezione 147</option>
                                                                                                <option value="148">Sezione 148</option>
                                                                                                <option value="149">Sezione 149</option>
                                                                                                <option value="150">Sezione 150</option>
                                                                                                <option value="151">Sezione 151</option>
                                                                                                <option value="152">Sezione 152</option>
                                                                                                <option value="153">Sezione 153</option>
                                                                                                <option value="154">Sezione 154</option>
                                                                                                <option value="155">Sezione 155</option>
                                                                                                <option value="156">Sezione 156</option>
                                                                                                <option value="157">Sezione 157</option>
                                                                                                <option value="158">Sezione 158</option>
                                                                                                <option value="159">Sezione 159</option>
                                                                                                <option value="160">Sezione 160</option>
                                                                                                <option value="161">Sezione 161</option>
                                                                                                <option value="162">Sezione 162</option>
                                                                                                <option value="163">Sezione 163</option>
                                                                                                <option value="164">Sezione 164</option>
                                                                                                <option value="165">Sezione 165</option>
                                                                                                <option value="166">Sezione 166</option>
                                                                                                <option value="167">Sezione 167</option>
                                                                                                <option value="168">Sezione 168</option>
                                                                                                <option value="169">Sezione 169</option>
                                                                                                <option value="170">Sezione 170</option>
                                                                                                <option value="171">Sezione 171</option>
                                                                                                <option value="172">Sezione 172</option>
                                                                                                <option value="173">Sezione 173</option>
                                                                                                <option value="174">Sezione 174</option>
                                                                                                <option value="175">Sezione 175</option>
                                                                                                <option value="176">Sezione 176</option>
                                                                                                <option value="177">Sezione 177</option>
                                                                                                <option value="178">Sezione 178</option>
                                                                                                <option value="179">Sezione 179</option>
                                                                                                <option value="180">Sezione 180</option>
                                                                                                <option value="181">Sezione 181</option>
                                                                                                <option value="182">Sezione 182</option>
                                                                                                <option value="183">Sezione 183</option>
                                                                                                <option value="184">Sezione 184</option>
                                                                                                <option value="185">Sezione 185</option>
                                                                                                <option value="186">Sezione 186</option>
                                                                                                <option value="187">Sezione 187</option>
                                                                                                <option value="188">Sezione 188</option>
                                                                                                <option value="189">Sezione 189</option>
                                                                                                <option value="190">Sezione 190</option>
                                                                                                <option value="191">Sezione 191</option>
                                                                                                <option value="192">Sezione 192</option>
                                                                                                <option value="193">Sezione 193</option>
                                                                                                <option value="194">Sezione 194</option>
                                                                                                <option value="195">Sezione 195</option>
                                                                                                <option value="196">Sezione 196</option>
                                                                                                <option value="197">Sezione 197</option>
                                                                                                <option value="198">Sezione 198</option>
                                                                                                <option value="199">Sezione 199</option>
                                                                                                <option value="200">Sezione 200</option>
                                                                                                <option value="201">Sezione 201</option>
                                                                                                <option value="202">Sezione 202</option>
                                                                                                <option value="203">Sezione 203</option>
                                                                                                <option value="204">Sezione 204</option>
                                                                                                <option value="205">Sezione 205</option>
                                                                                                <option value="206">Sezione 206</option>
                                                                                                <option value="207">Sezione 207</option>
                                                                                                <option value="208">Sezione 208</option>
                                                                                                <option value="209">Sezione 209</option>
                                                                                                <option value="210">Sezione 210</option>
                                                                                                <option value="211">Sezione 211</option>
                                                                                                <option value="212">Sezione 212</option>
                                                                                                <option value="213">Sezione 213</option>
                                                                                                <option value="214">Sezione 214</option>
                                                                                                <option value="215">Sezione 215</option>
                                                                                                <option value="216">Sezione 216</option>
                                                                                                <option value="217">Sezione 217</option>
                                                                                                <option value="218">Sezione 218</option>
                                                                                                <option value="219">Sezione 219</option>
                                                                                                <option value="220">Sezione 220</option>
                                                                                                <option value="221">Sezione 221</option>
                                                                                                <option value="222">Sezione 222</option>
                                                                                                <option value="223">Sezione 223</option>
                                                                                                <option value="224">Sezione 224</option>
                                                                                                <option value="225">Sezione 225</option>
                                                                                                <option value="226">Sezione 226</option>
                                                                                                <option value="227">Sezione 227</option>
                                                                                                <option value="228">Sezione 228</option>
                                                                                                <option value="229">Sezione 229</option>
                                                                                                <option value="230">Sezione 230</option>
                                                                                                <option value="231">Sezione 231</option>
                                                                                                <option value="232">Sezione 232</option>
                                                                                                <option value="233">Sezione 233</option>
                                                                                                <option value="234">Sezione 234</option>
                                                                                                <option value="235">Sezione 235</option>
                                                                                                <option value="236">Sezione 236</option>
                                                                                                <option value="237">Sezione 237</option>
                                                                                                <option value="238">Sezione 238</option>
                                                                                                <option value="239">Sezione 239</option>
                                                                                                <option value="240">Sezione 240</option>
                                                                                                <option value="241">Sezione 241</option>
                                                                                                <option value="242">Sezione 242</option>
                                                                                                <option value="243">Sezione 243</option>
                                                                                                <option value="244">Sezione 244</option>
                                                                                                <option value="245">Sezione 245</option>
                                                                                                <option value="246">Sezione 246</option>
                                                                                                <option value="247">Sezione 247</option>
                                                                                                <option value="248">Sezione 248</option>
                                                                                                <option value="249">Sezione 249</option>
                                                                                                <option value="250">Sezione 250</option>
                                                                                                <option value="251">Sezione 251</option>
                                                                                                <option value="252">Sezione 252</option>
                                                                                                <option value="253">Sezione 253</option>
                                                                                                <option value="254">Sezione 254</option>
                                                                                                <option value="255">Sezione 255</option>
                                                                                                <option value="256">Sezione 256</option>
                                                                                        </select> </div></li>

                            </ul>
                        </li>
                        <li><a href="/mappa-voto-risultati-camera.php#menu-nav">Mappe del voto</a>
                            <ul>
                                <li><div><a href="/mappa-voto-risultati-camera.php#menu-nav">Mappa del voto</a></div></li>

                            </ul>
                        </li>
                </li>
            </ul>
            </li>
            </ul>

        </nav>
    </div>
</section>

    <div id="main"><style>
    div.percentuale {font-size: 30px; font-weight: bold}
</style>
<div class="u-layout-wide u-layoutCenter u-text-r-xl u-layout-r-withGutter u-padding-r-top">

    <div class="Grid Grid--equalHeight Grid--withGutterM" id="servizi">

        <div class="Grid-cell u-sizeFull u-padding-r-bottom">
            <h2 class="u-text-h2"><a class="u-color-black u-textClean u-text-h2" href="">Rilevazione Affluenze</a></h2>
        </div>
        <table class="Table Table--striped Table--hover Table--withBorder">
            <thead>
                <tr class="u-border-bottom-xs">
                    <th scope="col" class="u-textLeft">Affluenza</th>
                    <th scope="col" class="u-textRight">%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th scope="col" class="u-textLeft">Sezioni</th>
                    <th scope="col" class="u-textRight">Votanti</th>
<!--                    <th scope="col" class="u-textRight">Iscritti sezioni pervenute</th>-->
                    <th scope="col" class="u-textRight">Iscritti Totali</th>
                </tr>
            </thead>
            <tbody>
                                    <tr class="u-textLeft">
                        <td class="u-textLeft">Ore 12 - Camera dei Deputati</td>
                        <td class="u-textRight"><div class="percentuale">21,88%</div></td>
                        <td class="u-textLeft">256 su 256</td>
                        <td class="u-textRight">42.722</td>
<!--                        <td class="u-textRight">195.202</td>-->
                        <td class="u-textRight">195.202</td>
                    </tr>
                                        <tr class="u-textLeft">
                        <td class="u-textLeft">Ore 19 - Camera dei Deputati</td>
                        <td class="u-textRight"><div class="percentuale">61,97%</div></td>
                        <td class="u-textLeft">256 su 256</td>
                        <td class="u-textRight">120.980</td>
<!--                        <td class="u-textRight">195.202</td>-->
                        <td class="u-textRight">195.202</td>
                    </tr>
                                        <tr class="u-textLeft">
                        <td class="u-textLeft">Ore 23 - Camera dei Deputati</td>
                        <td class="u-textRight"><div class="percentuale">73,74%</div></td>
                        <td class="u-textLeft">256 su 256</td>
                        <td class="u-textRight">143.953</td>
<!--                        <td class="u-textRight">195.202</td>-->
                        <td class="u-textRight">195.202</td>
                    </tr>
                                        <tr class="u-textLeft">
                        <td class="u-textLeft">Ore 23 - Senato della Repubblica</td>
                        <td class="u-textRight"><div class="percentuale">73,61%</div></td>
                        <td class="u-textLeft">256 su 256</td>
                        <td class="u-textRight">134.122</td>
<!--                        <td class="u-textRight">182.193</td>-->
                        <td class="u-textRight">182.193</td>
                    </tr>
                                </tbody>
        </table>
        <div style="color:#A40B25;font-weight: bold"><br><br>Ultimo aggiornamento: 06/03/2018 ore 15:35 - Dati ufficiosi<br><br></div>
    </div>

</div>



        <div class="u-background-grey-60 u-hiddenPrint">
            <div class="u-layout-wide u-layoutCenter u-layout-r-withGutter">
                <footer class="Footer u-background-grey-60">

                    <div class="u-cf">
                        <img class="Footer-logo" src="/immagini/logo/come-di-venezia_logo.png" alt="Comune di Venezia">
                        <p class="Footer-siteName">
                            <br>Città di Venezia
                        </p>
                    </div>
                    <div class="Grid Grid--withGutter">

                        <div class="Footer-block Grid-cell u-md-size1of4 u-lg-size1of4">
                            <h2 class="Footer-blockTitle">Recapiti e contatti</h2>
                            <div class="Footer-subBlock">
                                <h3 class="Footer-subTitle">Sede di Venezia Ca' <br> Farsetti</h3>
                                <address>
                                    San Marco 4136 <br>
                                    Telefono (+39) 041 2748111
                                </address>
                            </div>
                        </div>

                        <div class="Footer-block Grid-cell u-md-size1of4 u-lg-size1of4">
                            <h2 class="Footer-blockTitle"> <br> </h2>
                            <div class="Footer-subBlock">
                                <h3 class="Footer-subTitle">Sede di Mestre via <br> Palazzo</h3>
                                <address>
                                    Municipio, Via Palazzo 1 <br>
                                    tel. (+39) 041 2748111
                                </address>
                            </div>
                        </div>


                        <div class="Footer-block Grid-cell u-md-size1of4 u-lg-size1of4">
                            <h2 class="Footer-blockTitle"> <br> </h2>
                            <div class="Footer-subBlock">
                                <h3 class="Footer-subTitle">Centralino</h3>
                                <p>tel. (+39) 041 2748111</p>
                                
                            </div>
                        </div>

                        <div class="Footer-block Grid-cell u-md-size1of4 u-lg-size1of4">
                            <h2 class="Footer-blockTitle">Seguici su</h2>
                            <div class="Footer-subBlock">
                                <ul class="Footer-socialIcons">
                                    <li><a href="https://it-it.facebook.com/ComunediVenezia/" title="Facebook"><span class="Icon-facebook"></span><span class="u-hiddenVisually">Facebook</span></a></li>
                                    <li><a href="https://www.instagram.com/comunevenezia/" title="Instagram"><span class="Icon-instagram"></span><span class="u-hiddenVisually">Instagram</span></a></li>
                                    <li><a href="https://twitter.com/comunevenezia" title="Twitter"><span class="Icon-twitter"></span><span class="u-hiddenVisually">Twitter</span></a></li>
                                    <li><a href="https://www.youtube.com/channel/UCHQPCBBahWU0G1SvQgjomHw" title="Youtube"><span class="Icon-youtube"></span><span class="u-hiddenVisually">Youtube</span></a></li>
                                    <li><a href="http://www.venis.it/" title="Venis"><img src="/immagini/logo/venis.png" class="venisLogo" /><span class="Icon"></span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <ul class="Footer-links u-cf">
                        <li><a href="http://www.comune.venezia.it/content/note-legali" title="Note legali">Note legali</a></li>
                        <li><a href="http://www.comune.venezia.it/content/cookie-policy" title="Cookie Policy">Cookie Policy</a></li>
                        <li>C.F. 00339370272</li>
                        <li>Direttore responsabile: Paola Caporossi</li>
                        <br>
                        <li>Aut. Trib. di Venezia n. 1433 del 24.09.2002</li>
                        <li><b>© 2018 Comune di Venezia - Tutti i diritti riservati - Sviluppo VENIS S.p.A. Società in-house del Comune di Venezia</b></li>
                    </ul>

                </footer>

            </div>
        </div>

        <a href="#" title="torna all'inizio del contenuto" class="ScrollTop js-scrollTop js-scrollTo">
            <i class="ScrollTop-icon Icon-collapse" aria-hidden="true"></i>
            <span class="u-hiddenVisually">torna all'inizio del contenuto</span>
        </a>


    </div>


    <!--[if IE 8]>
    <script src="/build/vendor/respond.min.js"></script>
    <script src="/build/vendor/rem.min.js"></script>
    <script src="/build/vendor/selectivizr.js"></script>
    <script src="/build/vendor/slice.js"></script>
    <![endif]-->

    <!--[if lte IE 9]>
    <script src="/build/vendor/polyfill.min.js"></script>
    <![endif]-->
 <script>__PUBLIC_PATH__ = '/build/'</script>

    <script src="/build/IWT.min.js"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-6830106-15"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-6830106-15');
    </script>
    </body>
</html>